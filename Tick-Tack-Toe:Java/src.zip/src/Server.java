import java.awt.*;
import java.awt.print.Printable;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
import java.lang.String;
import java.util.concurrent.TimeUnit;




public class Server{
    static String[] GameBoard;
    static String PlayerTurn;
    static String PrintBoard(){
        String Printable ="  "+GameBoard[0]+"  "+"|"+"  "+GameBoard[1]+"  "+"|"+"  "+GameBoard[2]+"  \n" +
                "-----------------" +
                "  "+GameBoard[3]+"  "+"|"+"  "+GameBoard[4]+"  "+"|"+"  "+GameBoard[5]+"\n"+
                "-----------------"+
                "  "+GameBoard[6]+"  "+"|"+"  "+GameBoard[7]+"  "+"|"+"  "+GameBoard[8]+"\n";
        return Printable;

    }
    public static void main(String[] args) {
        GameBoard = new String[9];
        int playID1 = 0;
        int playID2 = 1;
        String play1msg = "You are Player X";
        String play2msg = " You are Player 0";
        PlayerTurn = "X";
        for(int i =0; i < 9; i++){
            GameBoard[i] = String.valueOf(i + 1);
        }
        try {
            System.out.println("Looking For players");
            ServerSocket player1 = new ServerSocket(5309);
            ServerSocket player2 = new ServerSocket(5310);




            Socket client1 = player1.accept();
            BufferedReader in = new BufferedReader(new InputStreamReader(client1.getInputStream()));
            String msg = in.readLine();
            System.out.println(msg);


            PrintWriter writer = new PrintWriter(client1.getOutputStream(), true);
            writer.println(playID1);
            writer.println(play1msg);
            writer.flush();


            Socket client2 = player2.accept();
            BufferedReader in1 = new BufferedReader(new InputStreamReader(client2.getInputStream()));
            String msg1 = in1.readLine();
            System.out.println(msg1);

            PrintWriter writer1 = new PrintWriter(client2.getOutputStream(), true);
            writer1.println(playID2);
            writer1.println(play1msg);
            writer.flush();



            System.out.println("Player Connected " + client1.getInetAddress().getHostAddress());
            System.out.println("Player Connected " + client2.getInetAddress().getHostAddress());
            System.out.println("Game will Start Now!");
            System.out.println(Printable);
            writer.println(Printable);
            writer1.println(Printable);
            writer.flush();
            writer1.flush();

            
        } catch(IOException e){
            e.printStackTrace();
        }

    }

    
    static String Player;

    static String WinCases() {
        boolean isTrue = true;
        if (GameBoard[0].equals(GameBoard[1]) && GameBoard[0].equals(GameBoard[2])) {//row1
            isTrue = false;
            Player = GameBoard[2];
        }
        if (GameBoard[3].equals(GameBoard[4]) && GameBoard[3].equals(GameBoard[5])) {//row2
            isTrue = false;
            Player = GameBoard[2];
        }
        if (GameBoard[6].equals(GameBoard[7]) && GameBoard[6].equals(GameBoard[8])) {//row3
            isTrue = false;
            Player = GameBoard[2];
        }
        if (GameBoard[0].equals(GameBoard[3]) && GameBoard[0].equals(GameBoard[6])) {//column1
            isTrue = false;
            Player = GameBoard[2];
        }
        if (GameBoard[1].equals(GameBoard[4]) && GameBoard[1].equals(GameBoard[7])) {//column2
            isTrue = false;
            Player = GameBoard[2];
        }
        if (GameBoard[2].equals(GameBoard[5]) && GameBoard[2].equals(GameBoard[8])) {//column3
            isTrue = false;
            Player = GameBoard[2];
        }
        if (GameBoard[0].equals(GameBoard[4]) && GameBoard[0].equals(GameBoard[8])) {//diagonal1
            isTrue = false;
            Player = GameBoard[2];
        }
        if (GameBoard[2].equals(GameBoard[4]) && GameBoard[2].equals(GameBoard[6])) {//diagonal2
            isTrue = false;
            Player = GameBoard[2];
        }
        if (!isTrue) {
            return "Winner is the " + Player + " player!\n";
        } else {
            return null;
        }

    }

}


