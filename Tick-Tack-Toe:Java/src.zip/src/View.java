import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.ServerSocket;

public class View {

    JFrame jFrame = new JFrame();
    JButton Button1 = new JButton();
    JButton Button2 = new JButton();
    JButton Button3 = new JButton();
    JButton Button4 = new JButton();
    JButton Button5 = new JButton();
    JButton Button6 = new JButton();
    JButton Button7 = new JButton();
    JButton Button8 = new JButton();
    JButton Button9 = new JButton();
    JOptionPane playerx = new JOptionPane("You are player X");
    JOptionPane playero = new JOptionPane("You are player O");
    JOptionPane player = new JOptionPane("You are player SERVER");

    View() {
        jFrame.setSize(600, 600);
        jFrame.setVisible(false);
        GridLayout grid = new GridLayout(4, 3, 10, 10);
        jFrame.setLayout(grid);
        jFrame.add(Button1);
        jFrame.add(Button2);
        jFrame.add(Button3);
        jFrame.add(Button4);
        jFrame.add(Button5);
        jFrame.add(Button6);
        jFrame.add(Button7);
        jFrame.add(Button8);
        jFrame.add(Button9);
        jFrame.add(player).setVisible(false);
        jFrame.add(playerx).setVisible(false);
        jFrame.add(playero).setVisible(false);



    }

}
