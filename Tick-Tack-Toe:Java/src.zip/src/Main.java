import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    static String[] GameBoard = new String[9];
    static String Player;
    static String WinCases(){
        boolean isTrue = true;
        if (GameBoard[0].equals (GameBoard[1]) && GameBoard[0].equals (GameBoard[2])) {//row1
            isTrue = false;
            Player = GameBoard[2];
        }
        if (GameBoard[3].equals(GameBoard[4]) && GameBoard[3].equals(GameBoard[5])) {//row2
            isTrue = false;
            Player = GameBoard[2];
        }
        if (GameBoard[6].equals(GameBoard[7]) && GameBoard[6].equals(GameBoard[8])) {//row3
            isTrue = false;
            Player = GameBoard[2];
        }
        if (GameBoard[0].equals(GameBoard[3]) && GameBoard[0].equals(GameBoard[6])) {//column1
            isTrue = false;
            Player = GameBoard[2];
        }
        if (GameBoard[1].equals(GameBoard[4]) && GameBoard[1].equals(GameBoard[7])) {//column2
            isTrue = false;
            Player = GameBoard[2];
        }
        if (GameBoard[2].equals(GameBoard[5]) && GameBoard[2].equals(GameBoard[8])) {//column3
            isTrue = false;
            Player = GameBoard[2];
        }
        if (GameBoard[0].equals(GameBoard[4]) && GameBoard[0].equals(GameBoard[8])) {//diagonal1
            isTrue = false;
            Player = GameBoard[2];
        }
        if (GameBoard[2].equals(GameBoard[4]) && GameBoard[2].equals(GameBoard[6])) {//diagonal2
            isTrue = false;
            Player = GameBoard[2];
        }
        if(!isTrue){
            return "Winner is the " + Player + " player!\n";
        }
        else{
            return null;
        }
    }
    public static void main(String[] args) {
        int count = 0;
        boolean isTrue = true, isInputInArray = false;
        int usrInput;
        Player = "X";
        String line = " ";
        System.out.println("Input a number 1-9 for a tic tac toe board (TL is 1, BR is 9)");
        BufferedReader sysIn = new BufferedReader(new InputStreamReader(System.in));
        while (isTrue) {
            try {
                line = sysIn.readLine();
            } catch (IOException e) {
                e.printStackTrace();
            }
            usrInput = Integer.parseInt(line);
            while(!isInputInArray) {
                if (GameBoard[usrInput] == null && Player.equals("X")) {
                    GameBoard[usrInput - 1] = String.valueOf('X');

                } else {
                    isInputInArray = true;
                    System.out.println("Please select a square with no inputs in it.");
                }
            }
            count++;
            if(count >=3) {
                WinCases();
                System.out.println(WinCases());
            }

            System.out.println(GameBoard[0] + " | " + GameBoard[1] + " | " + GameBoard[2]);
            System.out.println("---------");
            System.out.println(GameBoard[3] + " | " + GameBoard[4] + " | " + GameBoard[5]);
            System.out.println("---------");
            System.out.println(GameBoard[6] + " | " + GameBoard[7] + " | " + GameBoard[8]);




        }
    }
}
