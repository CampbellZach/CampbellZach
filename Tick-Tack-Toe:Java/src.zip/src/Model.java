
/*System.out.println("  "+GameBoard[0]+"  "+"|"+"  "+GameBoard[1]+"  "+"|"+"  "+GameBoard[2]+"  ");
        System.out.println("-----------------");
        System.out.println("  "+GameBoard[3]+"  "+"|"+"  "+GameBoard[4]+"  "+"|"+"  "+GameBoard[5]+"  ");
        System.out.println("-----------------");
        System.out.println("  "+GameBoard[6]+"  "+"|"+"  "+GameBoard[7]+"  "+"|"+"  "+GameBoard[8]+"  ");
*/