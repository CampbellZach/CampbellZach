import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.concurrent.TimeUnit;

public class Copy_Client extends Server {
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("127.0.0.1", 5310);
            String playID = "hello";
            PrintWriter writer = new PrintWriter(socket.getOutputStream(), true);
            writer.println(playID);
            writer.flush();
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            String msg = in.readLine();
            System.out.println(msg);


            while (true) {

            }
        } catch (IOException e) {
            e.printStackTrace();

        }
    }
}
